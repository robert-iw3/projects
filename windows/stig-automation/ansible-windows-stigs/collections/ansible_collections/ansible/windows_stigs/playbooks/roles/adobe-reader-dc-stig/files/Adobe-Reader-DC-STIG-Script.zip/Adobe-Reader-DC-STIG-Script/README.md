
# Automate Adobe Reader Pro DC STIG

Apply the Adobe Reader Pro DC STIGs in one simple script.


## STIGS/SRGs Applied:

- [Adobe Reader Pro DC Continous V1R2](https://dl.dod.cyber.mil/wp-content/uploads/stigs/zip/U_Adobe_Acrobat_Pro_DC_Classic_V1R3_STIG.zip)

- [Adobe Reader Pro DC Classic V1R3](https://dl.dod.cyber.mil/wp-content/uploads/stigs/zip/U_Adobe_Acrobat_Pro_DC_Continuous_V1R2_STIG.zip)


## How to run the script:

```
.\sos-adobe-stig.ps1
```

