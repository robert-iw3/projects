# FireFox STIG Script

This script will bring you up to 100% compliance minus 2 checks.

You must manually check Vul ID: **V-15770** and **V-15773**

## How to run the script

Windows:
```powershell
.\sos-firefoxstig.ps1
```

Linux:
```bash
sudo chmod +x ./sos-firefoxstig.sh
sudo bash ./sos-firefoxstig.sh
```

