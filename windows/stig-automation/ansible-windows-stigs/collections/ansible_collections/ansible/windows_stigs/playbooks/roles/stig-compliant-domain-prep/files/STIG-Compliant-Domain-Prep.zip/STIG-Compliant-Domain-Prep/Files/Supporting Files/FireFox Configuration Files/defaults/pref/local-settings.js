pref("general.config.filename", "mozilla.cfg");
pref("general.config.obscure_value", 0);
