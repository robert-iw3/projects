### Hunting for LOLBAS

This repo contains observed APT tactics using living off the land techniques to avoid detection and blend in with normal user traffic.

Examples of generating Sigma rules to detect these techniques along with SPL (splunk queries) and MS Defender for Endpoint queries.

https://github.com/SigmaHQ/sigma

